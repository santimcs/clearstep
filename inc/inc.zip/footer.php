<footer class="full-width foot">
    <div class="container">
        <div class="row">
            <div class="col-sm-6 col-md-3 widget">
                <h3>Stay In Touch</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris ut posuere mauris, eu malesuada dui. Vestibulum malesuada sit amet enim sit amet venenatis. Aliquam dapibus bibendum diam ac porttitor. Fusce ut suscipit augue, ut lacinia enim. Nunc sit amet lorem malesuada, gravida risus vel, auctor turpis.</p>
            </div>
            <div class="col-sm-6 col-md-6 widget">
				<h3>Our Company</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris ut posuere mauris, eu malesuada dui. Vestibulum malesuada sit amet enim sit amet venenatis. Aliquam dapibus bibendum diam ac porttitor. Fusce ut suscipit augue, ut lacinia enim. Nunc sit amet lorem malesuada, gravida risus vel, auctor turpis. Donec tincidunt accumsan malesuada. Praesent mauris odio, viverra sed porta non, aliquam eu libero.</p>
            </div>
            <div class="col-sm-6 col-md-3 widget visible-lg visible-md">
				<h3>Client Log In</h3>
				<form role="form" class="foot-form">
					<div class="form-group">
						<input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
					</div>
					<div class="form-group">
						<input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
					</div>
					<button type="submit" class="btn btn-primary">Submit</button>
				</form>
			</div><!--end footer widget -->
        </div><!--end row -->
    </div><!--end container -->
</footer><!--end footer -->
        
<div class="credits">
    <div class="container">
        <div class="row">
            <p class="col-md-10">&copy; ClearStep Consultants LLC. All Rights Reserved 2013</p>
            <aside class="social pull-right col-md-2">
                <a class="icon-facebook-sign" href="#" title="Follow Us On Facebook"></a>
                <a class="icon-twitter-sign" href="#" title="Follow Us On Twitter"></a>
            </aside>
        </div><!--end row -->
    </div><!--end container -->
</div><!--end credits -->

        


        <script src="js/bootstrap.min.js"></script>
        <script src="js/plugins.js"></script>
        <script src="js/main.js"></script>

    </body>
</html>